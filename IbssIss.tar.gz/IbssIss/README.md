# IbssIss

Assigns GPS positions to named survey locations in the **Inshore Breeding Stock Survey (IBSS)** and **Inshore Survey (ISS)**, using pre-defined polygon boundaries for all sites along the Western Australian coast.

## Installation

```r
# install.packages("devtools")
devtools::install_github("dpird-fish/IbssIss")
```

Or install locally:

```r
devtools::install("path/to/IbssIss")
```

## Usage

```r
library(IbssIss)

coords <- data.frame(Lat = c(-32.18, -30.5), Lon = c(115.48, 114.9))

# Polygon-based assignment (NA → "notibss" for points outside all polygons)
getlocpolyibss(coords)
getlocpolyibss(coords, subloc = TRUE)

# Nearest-centroid fallback (always assigns something)
getlocspointibss(coords, subloc = TRUE)

# ISS equivalents
getlocpolyiss(coords)
getlocspointiss(coords)
```

## Functions

| Function | Survey | Method |
|---|---|---|
| `getlocpolyibss()` | IBSS | Polygon (point-in-polygon) |
| `getlocpolyiss()` | ISS | Polygon (point-in-polygon) |
| `getlocspointibss()` | IBSS | Nearest centroid |
| `getlocspointiss()` | ISS | Nearest centroid |

Both methods accept a `subloc` argument to switch between main site and sub-location labels, and a `survey` argument to restrict the polygon set tested.

## Data

- `ibsspoly` — list of IBSS polygon definitions (15 sub-locations)
- `isspoly` — list of ISS polygon definitions

To rebuild these datasets from source, run `source("data-raw/build_polygons.R")` from the package root.

## Rebuilding datasets

Polygon edits should be made in `data-raw/ibsspoly_source.R` (for IBSS) or by replacing `data-raw/isspoly.rda` (for ISS), then running:

```r
source("data-raw/build_polygons.R")
```
