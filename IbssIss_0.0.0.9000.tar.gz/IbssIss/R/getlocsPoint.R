#' Finds IBSS or ISS locations based on the closest point.
#'
#' This function takes a matrix of GPS positions and returns the closest IBSS or ISS location.
#' If subloc is set to True, then closest sublocation is returned.
#'
#' @param x a matrix with latitude and longitude in columns in decimal DD.MMSS
#' @return The IBSS or ISS location (or sublocation)
#' @examples
#' getlocsPoint(as.matrix(cbind(DecimalLatitude, DecimalLongitude)), subloc=T, survey="IBSS")
#' @export
getlocsPoint <- function (x, subloc=F, survey = "ISS")
{
  wmin <- function(x) return(which.min(x)[1])
  lat <- -abs(x[, 1])
  lon <- x[, 2]
  dist <- matrix(0,nrow=length(lat), ncol=length(ibssisspoly))
  names2 <- names <- rep(NA, length(ibssisspoly))
  for (i in 1:length(ibssisspoly)) {
    names[i] <- as.character(unique(ibssisspoly[[i]]$Site))
    names2[i] <- as.character(unique(ibssisspoly[[i]]$SubLoc))
    a <- (lon-mean(ibssisspoly[[i]]$x))^2
    b <- (lat-mean(ibssisspoly[[i]]$y))^2
    y <- sqrt(a+b)
    dist[,i] <- y}
  dist <- dist[,grepl(survey,names)]
  names <- names[grepl(survey,names)]
  names2 <- names2[grepl(survey,names)]
  pos <- apply(dist,1,wmin)
  if (subloc==F){ return(names[pos])} else { return(names2[pos])}
}
