#' Finds IBSS or ISS locations based on whenther they fall within a polygon.
#'
#' This function takes a matrix. of GPS positions and returns the IBSS or ISS location.
#' If subloc is set to True, then sublocation is returned.  Some areas have a cross-over between IBSS and ISS (Abrolhos).
#' You can pre-specify a survey to be assigned using the survey command.
#'
#' @param x a matrix with latitude and longitude in columns in decimal DD.MMSS
#' @return The IBSS or ISS location (or sublocation)
#' @examples
#' getlocsPoly(as.matrix(cbind(DecimalLatitude, DecimalLongitude)), subloc=T, survey="IBSS")
#' @export
getlocsPoly <- function (x, subloc = F, survey = ""){  ## x = as.matrix(cbind(DecimalLat,DecimalLon))
  lat <- -abs(x[, 1])
  lon <- x[, 2]
  tmp <- rep(NA, length(lat))
  for (i in 1:length(ibssisspoly)) {
    if(survey=="" | grepl(survey,ibssisspoly[[i]]$SiteCode,ignore.case = T)){
      if (subloc == F)
        tmp[(sp::point.in.polygon(lon, lat, ibssisspoly[[i]]$x,
                                  ibssisspoly[[i]]$y)) == 1] <- as.character(ibssisspoly[[i]]$Site[1])
      if (subloc == T)
        tmp[(sp::point.in.polygon(lon, lat, ibssisspoly[[i]]$x,
                                  ibssisspoly[[i]]$y)) == 1] <- as.character(ibssisspoly[[i]]$SubLoc[1])
    }
  }
  tmp[is.na(tmp)] <- "notibssiss"
  return(tmp)
}











